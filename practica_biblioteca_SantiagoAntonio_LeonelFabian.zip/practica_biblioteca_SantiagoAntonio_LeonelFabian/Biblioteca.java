import java.rmi.*;
import java.util.*;

public interface Biblioteca extends Remote {
    boolean autenticar(String usuario, String nip) throws RemoteException;
    List<String> listarLibros() throws RemoteException;
    boolean prestar(String usuario, String libro) throws RemoteException;
    boolean devolver(String usuario, String libro) throws RemoteException;
    List<String> misPrestamos(String usuario) throws RemoteException;
    boolean cambiarNip(String usuario, String nipActual, String nipNuevo) throws RemoteException;
}