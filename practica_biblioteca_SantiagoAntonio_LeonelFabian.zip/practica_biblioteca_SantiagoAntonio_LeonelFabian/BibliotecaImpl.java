import java.rmi.*;
import java.rmi.server.*;
import java.util.*;

public class BibliotecaImpl extends UnicastRemoteObject implements Biblioteca {

    private static final int MAX_INTENTOS = 3;
    private static final int MAX_PRESTAMOS = 3;

    private HashMap<String, String> usuarios = new HashMap<>();
    private HashMap<String, Integer> intentos = new HashMap<>();
    private HashMap<String, ArrayList<String>> prestamos = new HashMap<>();
    private ArrayList<String> libros = new ArrayList<>();

    public BibliotecaImpl() throws RemoteException {
        super();
        usuarios.put("ana", "1234");
        usuarios.put("luis", "5678");
        prestamos.put("ana", new ArrayList<>());
        prestamos.put("luis", new ArrayList<>());

        libros.add("Don Quijote");
        libros.add("Cien años de soledad");
        libros.add("El principito");
        libros.add("Java para todos");
        libros.add("Redes de computadoras");
    }

    public boolean autenticar(String usuario, String nip) {
        System.out.println("[Servidor] Autenticando a " + usuario);
        int fallidos = intentos.getOrDefault(usuario, 0);
        if (fallidos >= MAX_INTENTOS) {
            System.out.println("[Servidor] Usuario bloqueado: " + usuario);
            return false;
        }
        String nipGuardado = usuarios.get(usuario);
        if (nipGuardado != null && nipGuardado.equals(nip)) {
            intentos.put(usuario, 0);
            return true;
        }
        if (nipGuardado != null) {
            intentos.put(usuario, fallidos + 1);
        }
        return false;
    }

    public List<String> listarLibros() {
        System.out.println("[Servidor] Ejecutando listarLibros()");
        return new ArrayList<>(libros);
    }

    public boolean prestar(String usuario, String libro) {
        System.out.println("[Servidor] Ejecutando prestar(" + usuario + ", " + libro + ")");
        ArrayList<String> susLibros = prestamos.get(usuario);
        if (susLibros == null) {
            return false;
        }
        if (susLibros.size() >= MAX_PRESTAMOS) {
            return false;
        }
        if (!libros.contains(libro)) {
            return false;
        }
        libros.remove(libro);
        susLibros.add(libro);
        return true;
    }

    public boolean devolver(String usuario, String libro) {
        System.out.println("[Servidor] Ejecutando devolver(" + usuario + ", " + libro + ")");
        ArrayList<String> susLibros = prestamos.get(usuario);
        if (susLibros == null || !susLibros.contains(libro)) {
            return false;
        }
        susLibros.remove(libro);
        libros.add(libro);
        return true;
    }

    public List<String> misPrestamos(String usuario) {
        System.out.println("[Servidor] Ejecutando misPrestamos(" + usuario + ")");
        ArrayList<String> susLibros = prestamos.get(usuario);
        if (susLibros == null) {
            return new ArrayList<>();
        }
        return new ArrayList<>(susLibros);
    }

    public boolean cambiarNip(String usuario, String nipActual, String nipNuevo) {
        System.out.println("[Servidor] Ejecutando cambiarNip(" + usuario + ")");
        String nipGuardado = usuarios.get(usuario);
        if (nipGuardado == null || !nipGuardado.equals(nipActual)) {
            return false;
        }
        if (nipNuevo == null || nipNuevo.length() != 4) {
            return false;
        }
        usuarios.put(usuario, nipNuevo);
        return true;
    }
}
