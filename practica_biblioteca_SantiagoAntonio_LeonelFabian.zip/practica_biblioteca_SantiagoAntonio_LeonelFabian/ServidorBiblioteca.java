import java.rmi.registry.*;

public class ServidorBiblioteca {
    public static void main(String[] args) throws Exception {
        BibliotecaImpl biblioteca = new BibliotecaImpl();

        Registry registro = LocateRegistry.createRegistry(1099);
        registro.rebind("Biblioteca", biblioteca);

        System.out.println("Servidor RMI listo. Objeto \"Biblioteca\" registrado en el puerto 1099.");
    }
}