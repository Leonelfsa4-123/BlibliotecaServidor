import java.rmi.registry.*;
import java.util.*;

public class ClienteBiblioteca {
    public static void main(String[] args) throws Exception {
        Registry registro = LocateRegistry.getRegistry("localhost", 1099);
        Biblioteca bib = (Biblioteca) registro.lookup("Biblioteca");
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== BIBLIOTECA RMI ===");

        // ----- LOGIN: máximo 3 intentos -----
        boolean acceso = false;
        String usuario = "";
        for (int intento = 1; intento <= 3 && !acceso; intento++) {
            System.out.print("Usuario: ");
            usuario = scanner.nextLine();
            System.out.print("NIP: ");
            String nip = scanner.nextLine();

            acceso = bib.autenticar(usuario, nip);
            if (!acceso) {
                System.out.println("Datos incorrectos o usuario bloqueado. Intento " + intento + " de 3");
            }
        }

        if (!acceso) {
            System.out.println("Acceso denegado.");
            scanner.close();
            return;
        }

        System.out.println("Bienvenido, " + usuario);

        // ----- MENÚ -----
        int opcion = 0;
        do {
            System.out.println();
            System.out.println("1. Ver libros disponibles");
            System.out.println("2. Pedir prestado un libro");
            System.out.println("3. Devolver un libro");
            System.out.println("4. Ver mis préstamos");
            System.out.println("5. Cambiar NIP");
            System.out.println("6. Salir");
            System.out.print("Opción: ");

            try {
                opcion = Integer.parseInt(scanner.nextLine());

                switch (opcion) {
                    case 1: {
                        List<String> disponibles = bib.listarLibros();
                        if (disponibles.isEmpty()) {
                            System.out.println("No hay libros disponibles.");
                        } else {
                            System.out.println("Libros disponibles:");
                            for (String l : disponibles) {
                                System.out.println(" - " + l);
                            }
                        }
                        break;
                    }
                    case 2: {
                        List<String> disponibles = bib.listarLibros();
                        for (int i = 0; i < disponibles.size(); i++) {
                            System.out.println((i + 1) + ". " + disponibles.get(i));
                        }
                        System.out.print("Número del libro: ");
                        int num = Integer.parseInt(scanner.nextLine());
                        if (num < 1 || num > disponibles.size()) {
                            System.out.println("Número fuera de rango.");
                        } else if (bib.prestar(usuario, disponibles.get(num - 1))) {
                            System.out.println("Préstamo realizado.");
                        } else {
                            System.out.println("No se pudo prestar (límite de 3 libros o ya no está disponible).");
                        }
                        break;
                    }
                    case 3: {
                        List<String> mios = bib.misPrestamos(usuario);
                        if (mios.isEmpty()) {
                            System.out.println("No tienes libros prestados.");
                        } else {
                            for (int i = 0; i < mios.size(); i++) {
                                System.out.println((i + 1) + ". " + mios.get(i));
                            }
                            System.out.print("Número del libro a devolver: ");
                            int num = Integer.parseInt(scanner.nextLine());
                            if (num < 1 || num > mios.size()) {
                                System.out.println("Número fuera de rango.");
                            } else if (bib.devolver(usuario, mios.get(num - 1))) {
                                System.out.println("Libro devuelto.");
                            } else {
                                System.out.println("No se pudo devolver.");
                            }
                        }
                        break;
                    }
                    case 4: {
                        List<String> mios = bib.misPrestamos(usuario);
                        if (mios.isEmpty()) {
                            System.out.println("No tienes libros prestados.");
                        } else {
                            System.out.println("Tus libros prestados:");
                            for (String l : mios) {
                                System.out.println(" - " + l);
                            }
                        }
                        break;
                    }
                    case 5: {
                        System.out.print("NIP actual: ");
                        String actual = scanner.nextLine();
                        System.out.print("NIP nuevo (4 caracteres): ");
                        String nuevo = scanner.nextLine();
                        if (bib.cambiarNip(usuario, actual, nuevo)) {
                            System.out.println("NIP cambiado correctamente.");
                        } else {
                            System.out.println("No se pudo cambiar el NIP.");
                        }
                        break;
                    }
                    case 6:
                        System.out.println("Hasta luego.");
                        break;
                    default:
                        System.out.println("Opción no válida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Debes escribir un número.");
                opcion = 0;
            }
        } while (opcion != 6);

        scanner.close();
    }
}
